package beans;

import javax.ejb.Remote;

@Remote
public interface ManageBeanRemote {

    /**
     * Adds a LabSession to a Course. If the LabSession and/or Course does not exist, 
     * it is created. 
     * 
     * @param name The title of the Course
     * @param title The name of the LabSession
     * @return Returns true if the LabSession was successfully added to the 
     * Course, false otherwise. 
     */
    public boolean addLabSessiontoCourse(String name, String title);

    /**
     * Creates a new LabSession, if the LabSession did not exist yet
     * 
     * @param title The name of the LabSession
     * @return Returns true if the LabSession was successfully created, 
     * false otherwise. 
     */
    public boolean createLabSession(String title);

    /**
     * Removes a LabSession from the Course.
     * 
     * @param name The title of the Course
     * @param title The name of the LabSession
     * @return Returns true if the LabSession was successfully removed to the 
     * Course, false otherwise. 
     */
    public boolean removeLabSessionfromCourse(String name, String title);
    
}
