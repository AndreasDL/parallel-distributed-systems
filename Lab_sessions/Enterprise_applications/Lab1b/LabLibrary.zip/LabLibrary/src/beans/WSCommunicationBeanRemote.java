package beans;

import javax.ejb.Remote;
import util.ResultDetails;

@Remote
public interface WSCommunicationBeanRemote {

    /**
     * This method queries the RESTful Web Service and processes the JSON string 
     * which is returned. A new Result is created and added to the PDSGroup. A ResultDetails 
     * object is returned.
     * 
     * @param ip The address where the RESTful Web Service is located
     * @param name The name of the LabSession	
     * @param group The group number which is executing the call
     * @param delay The delay that is on the link
     * @return The ResultDetails class, containing the results of the call
     */
    public ResultDetails process(String ip, String name, int group, int delay);
    
}
