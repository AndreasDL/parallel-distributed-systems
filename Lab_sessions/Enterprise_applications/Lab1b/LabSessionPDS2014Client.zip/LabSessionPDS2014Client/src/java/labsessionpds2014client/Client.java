package labsessionpds2014client;

import beans.ManageBeanRemote;
import beans.WSCommunicationBeanRemote;
import javax.ejb.EJB;
import util.ResultDetails;

public class Client {
    
    @EJB
    private static ManageBeanRemote managementBean;
    @EJB
    private static WSCommunicationBeanRemote wSCommunicationBean;

    public static void main(String[] args)  {
        String ip = args[0];
        int group = Integer.parseInt(args[1]);
        int delay = Integer.parseInt(args[2]);
        System.out.println("Create Enterprise Applications: " + managementBean.addLabSessiontoCourse("Enterprise Applications", "Parallel and Distributed Software Systems"));
        System.out.println("Create Resource Allocation: " +  managementBean.addLabSessiontoCourse("Resource Allocation", "Parallel and Distributed Software Systems"));
        System.out.println("Create Resource Allocation: " +  managementBean.addLabSessiontoCourse("Resource Allocation", "Parallel and Distributed Software Systems"));

        ResultDetails result = wSCommunicationBean.process(ip, "Enterprise Applications", group, delay);
        if (result != null) {
            System.out.println("Start time: " + result.getStartTime());
            System.out.println("Stop time: " + result.getStopTime());
            System.out.println("Difference: " + result.getDelta());
            System.out.println("Group number: " + group);
            System.out.println("Delay: " + result.getDelay());
        } else {
            System.out.println("Querying WS failed!");
        }
    }

}
