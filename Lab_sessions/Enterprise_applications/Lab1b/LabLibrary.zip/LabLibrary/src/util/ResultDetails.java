package util;

import java.io.Serializable;

public class ResultDetails implements Serializable {

    private long startTime;

    private long stopTime;

    private long delta;

    private long delay;

    private int hash;

    public ResultDetails(long startTime, long stopTime, long delta, long delay, int hash) {
        this.startTime = startTime;
        this.stopTime = stopTime;
        this.delta = delta;
        this.delay = delay;
        this.hash = hash;
    }

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public long getStopTime() {
        return stopTime;
    }

    public void setStopTime(long stopTime) {
        this.stopTime = stopTime;
    }

    public long getDelta() {
        return delta;
    }

    public void setDelta(long delta) {
        this.delta = delta;
    }

    public long getDelay() {
        return delay;
    }

    public void setDelay(long delay) {
        this.delay = delay;
    }

    public int getHash() {
        return hash;
    }

    public void setHash(int hash) {
        this.hash = hash;
    }

}
